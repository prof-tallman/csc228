
Introduce self
  Picture of family
  15 years as cybersecurity consultant
  7 years in Europe
  Daughters born in Europe
  Example from Crimple Valley Fresh
    URLs (show one with parameters)
    How shopping carts normally work (cookies?)
    Encoded in URL
    Press buttons, items added to URL (gets really long)
    What happens if I change these numbers
    Differences between what programmers expected, what the hacker (user) actually does, how the webserver responds

SQL Injection
  Show some simple HTML - what is this?
  Basic webpage uses HTML and style sheet
  Modern websites--yours included, no doubt--include code in the page (TODO: find example to share)
  Most websites--yours too, probably--are the main interface to a large database
    Inventory
    Sales data
    Customer lists
    Operational data (sports statistics, weather, flight data, stock market, etc.)
    Data is usually stored in a database on another computer
    Webserver issues a query to database, retrieves the data, and then displays it to the user
    User might enter a search term, click some buttons, and "wala"
    Actual query from webserver to database is written in a format called SQL
    SELECT name, position, batting_avg, homeruns, era FROM players WHERE team = 'Padres'
    SELECT name, position, batting_avg, homeruns, era FROM players WHERE team = 'Dodgers'
    SELECT item, part_number, price, quantity FROM inventory WHERE category = 'Widgets' ORDER BY price
    SELECT item, part_number, price, quantity FROM inventory WHERE category = 'Clothing' ORDER BY price
    SELECT item, part_number, price, quantity FROM inventory WHERE category = 'Tools' ORDER BY part_number
    SELECT item, part_number, price, quantity FROM inventory WHERE category = '<THIS FIELD COMES FROM AN INPUT ON THE WEBSERVER>' ORDER BY <THIS FIELD PROBABLY COMES FROM THE WEBSERVER TOO>
  Problem is that the programmers vs hacker (user) and how the webserver responds
    Go back to here: SELECT name, position, batting_avg, homeruns, era FROM players WHERE team = 'Dodgers'
    Change to something else: SELECT * FROM customer_list WHERE customer_id = '5789234'
    Change to something else: SELECT * FROM customer_list WHERE customer_id = '5789234' AND year = '2025'
    Assuming that the customer numbers are long and random so that it is infeasible to guess another customer
    Change to something else: SELECT * FROM customer_list WHERE customer_id = '<THIS FIELD COMES FROM WEBSERVER INPUT>'
    Programmer assumes that users are going to enter customer ID and *only* a customer ID
    But what happens if a (sneaky) user combines data with more SQL code?
    Go back and show this query: SELECT * FROM customer_list WHERE customer_id = '5789234' AND year = '2025'
    Ask if they think there are any other basic *logic* operators that SQL understands
      'AND' is a logic operator
    What if we could change the query to SELECT * FROM customer_list WHERE customer_id = '5789234' OR year = '2025'
      But wait, the query only includes the bit about customer_id number, where did the OR year = '2025' come from?
      Here was the "customer_id" that the user searched for:
        5789234' OR year = '2025'
        Show the query side-by-side with the input and show how it is inserted
    Minor fixup issue
      Like the trailing ' --> it causes an error
      We can end the SQL command early with the "--" comment instruction
      The "--" means that everything after is a comment (programmer note), and should be ignored by the SQL database
      So we can turn the trailing ' into part of a comment
    This "SQL injection" allows us to see every record in the customer_list database table for the year 2025 (we could change the year and run it again)
    Notice that we assumed the hacker knew ahead of time that the *year* column existed in the database (they often do not know this)
    There's an even more powerful query that lets us see all of them at once, it's particularly useful when the hacker does not know the internal structure of the database
      xxxxx' OR 1 = 1
      xxxxx' OR 2 = 2
      xxxxx' OR 3 = 3
      xxxxx' OR 42 = 42
      The right side of the OR statement is always true, so it doesn't matter what the customer number is!
      It's like if we said, "invite all business owners who live on the 800 block of Culver Drive OR are human"

Webserver
  Explain that we have a mock webserver with a backend database
  The webserver has been programmed with realistic vulnerabilities in it
  But the look/feel of the webserver might not be particularly realistic...
    The mock website is somewhat contrived (but use your imagination)
      It is in the middle of the page and looks like this
    There's also a bit of text at the bottom that reminds us how to fix the website vulnerabilities (more on this later)
    It has some buttons on the top that are clearly related the exercise
    It also has an "inspection" view on the top to help novice "hackers"
      They look like this
      The inspection view is not available by default because it is somewhat of a cheat mode
      However, if you do not know SQL, I suggest that you turn on the cheat code
      The inspection view allows you to see how your input is embedded in the SQL query itself

Tasks
    


Find some examples of famous SQL query hacks
Get the Bobby Tables cartoon
    
Show how to fix


